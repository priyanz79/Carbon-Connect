import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Dashboard from "@/pages/dashboard";
import NgoDashboard from "@/pages/ngo-dashboard";
import AdminDashboard from "@/pages/admin-dashboard";
import Projects from "@/pages/projects";
import ProjectDetail from "@/pages/project-detail";
import MrvCapture from "@/pages/mrv-capture";
import Credits from "@/pages/credits";
import VerifierDashboard from "@/pages/verifier-dashboard";
import VerificationDetail from "@/pages/verification-detail";

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();

  // Handle role update after login
  useEffect(() => {
    const handleRoleUpdate = async () => {
      if (isAuthenticated && user) {
        const selectedRole = localStorage.getItem("selectedRole");
        if (selectedRole && selectedRole !== user.role) {
          try {
            await apiRequest("PATCH", "/api/auth/user/role", { role: selectedRole });
            localStorage.removeItem("selectedRole");
            // Refresh the page to get updated user data
            window.location.reload();
          } catch (error) {
            console.error("Failed to update user role:", error);
            localStorage.removeItem("selectedRole");
          }
        }
      }
    };

    handleRoleUpdate();
  }, [isAuthenticated, user]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Function to get the appropriate dashboard based on user role
  const getDashboardComponent = () => {
    if (!user || !user.role) return Dashboard;
    
    switch (user.role) {
      case "ngo":
        return NgoDashboard;
      case "admin":
        return AdminDashboard;
      case "verifier":
        return VerifierDashboard;
      case "community":
      default:
        return Dashboard;
    }
  };

  return (
    <Switch>
      {!isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/" component={getDashboardComponent()} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/ngo" component={NgoDashboard} />
          <Route path="/admin" component={AdminDashboard} />
          <Route path="/projects" component={Projects} />
          <Route path="/projects/:id" component={ProjectDetail} />
          <Route path="/mrv-capture" component={MrvCapture} />
          <Route path="/credits" component={Credits} />
          <Route path="/verifier" component={VerifierDashboard} />
          <Route path="/verifier/:id" component={VerificationDetail} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
