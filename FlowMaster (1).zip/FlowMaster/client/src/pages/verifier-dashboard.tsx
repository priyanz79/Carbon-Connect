import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import { ShieldCheck, Bell, Filter, Camera, Eye } from "lucide-react";

export default function VerifierDashboard() {
  const [, navigate] = useLocation();
  const { user } = useAuth();

  const { data: pendingSubmissions, isLoading } = useQuery({
    queryKey: ["/api/verifier/pending-submissions"],
    enabled: !!user && user.role === "verifier",
  });

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  if (user?.role !== "verifier") {
    navigate("/");
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Verifier Header */}
      <div className="bg-card border-b border-border px-6 pt-16 pb-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-foreground" data-testid="text-verifier-name">
                {user.firstName && user.lastName 
                  ? `${user.firstName} ${user.lastName}` 
                  : user.email}
              </h1>
              <p className="text-sm text-muted-foreground">Environmental Verifier</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <Bell className="w-5 h-5 text-muted-foreground" />
            </Button>
            <Button
              onClick={handleLogout}
              variant="ghost"
              size="sm"
              className="text-muted-foreground"
              data-testid="button-logout"
            >
              Logout
            </Button>
          </div>
        </div>

        {/* Verification Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-3 bg-primary/5 rounded-lg">
            <p className="text-lg font-bold text-primary" data-testid="text-pending-count">
              {pendingSubmissions?.length || 0}
            </p>
            <p className="text-xs text-muted-foreground">Pending</p>
          </div>
          <div className="text-center p-3 bg-secondary/5 rounded-lg">
            <p className="text-lg font-bold text-secondary" data-testid="text-verified-count">
              {/* This would need to be tracked separately */}
              0
            </p>
            <p className="text-xs text-muted-foreground">Verified</p>
          </div>
          <div className="text-center p-3 bg-muted rounded-lg">
            <p className="text-lg font-bold text-foreground" data-testid="text-rejected-count">
              {/* This would need to be tracked separately */}
              0
            </p>
            <p className="text-xs text-muted-foreground">Rejected</p>
          </div>
        </div>
      </div>

      {/* Pending Submissions */}
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Pending Verifications</h2>
          <Button variant="outline" size="sm">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-card border border-border rounded-lg p-4 animate-pulse">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className="w-12 h-12 bg-muted rounded-lg"></div>
                    <div className="space-y-2">
                      <div className="h-4 bg-muted rounded w-32"></div>
                      <div className="h-3 bg-muted rounded w-48"></div>
                      <div className="h-3 bg-muted rounded w-24"></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-3 bg-muted rounded w-16"></div>
                    <div className="h-3 bg-muted rounded w-12"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : pendingSubmissions && pendingSubmissions.length > 0 ? (
          <div className="space-y-4">
            {pendingSubmissions.map((submission: any) => (
              <Card 
                key={submission.id} 
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => navigate(`/verifier/${submission.id}`)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start space-x-3">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                        submission.eventType === 'planting' ? 'bg-primary/10' : 'bg-secondary/10'
                      }`}>
                        {submission.eventType === 'planting' ? (
                          <Camera className="w-6 h-6 text-primary" />
                        ) : (
                          <Eye className="w-6 h-6 text-secondary" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="font-medium text-card-foreground capitalize">
                            {submission.eventType} Event
                          </h3>
                          <span className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">
                            High Priority
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">
                          {submission.projectName}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Submitted by {submission.userName}
                        </p>
                      </div>
                    </div>
                    <div className="text-right text-xs text-muted-foreground">
                      <p>{new Date(submission.createdAt).toLocaleTimeString()}</p>
                      <p className="flex items-center space-x-1 mt-1">
                        <Camera className="w-3 h-3" />
                        <span>{Array.isArray(submission.photos) ? submission.photos.length : 0} photos</span>
                      </p>
                    </div>
                  </div>
                  
                  <div className="bg-muted rounded-lg p-3 mb-3">
                    <p className="text-sm text-muted-foreground">
                      {submission.notes || `${submission.eventType} activity recorded`}
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span className="flex items-center space-x-2">
                      <span>📍</span>
                      <span>
                        {submission.gpsLatitude && submission.gpsLongitude
                          ? `${parseFloat(submission.gpsLatitude).toFixed(4)}°N, ${parseFloat(submission.gpsLongitude).toFixed(4)}°E`
                          : "Location not available"}
                      </span>
                    </span>
                    <span>
                      {submission.species || submission.eventType}: {submission.saplingsPlanted || 0} saplings
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-muted-foreground">No pending submissions</p>
            </CardContent>
          </Card>
        )}

        {pendingSubmissions && pendingSubmissions.length > 0 && (
          <div className="mt-6 text-center">
            <Button variant="link">Load More Submissions</Button>
          </div>
        )}
      </div>
    </div>
  );
}
