import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import BottomNavigation from "@/components/bottom-navigation";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import { ArrowLeft, Download, PlusCircle, Clock, Filter } from "lucide-react";

export default function Credits() {
  const [, navigate] = useLocation();
  const { user } = useAuth();

  const { data: transactions, isLoading } = useQuery({
    queryKey: ["/api/credits/transactions"],
    enabled: !!user,
  });

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "earned":
        return <PlusCircle className="w-5 h-5 text-primary" />;
      default:
        return <Clock className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case "earned":
        return "text-primary";
      default:
        return "text-muted-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Credits Header */}
      <div className="bg-gradient-to-br from-primary to-secondary text-white px-6 pt-16 pb-8">
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/")}
            className="text-white hover:bg-white/20"
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-semibold">My Credits</h1>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20"
          >
            <Download className="w-5 h-5" />
          </Button>
        </div>

        <div className="text-center mb-6">
          <p className="text-sm opacity-90 mb-2">Total Credits Earned</p>
          <p className="text-4xl font-bold" data-testid="text-total-credits">
            {user?.totalCredits || 0}
          </p>
          <p className="text-sm opacity-75" data-testid="text-estimated-value">
            Estimated value: ₹{((user?.totalCredits || 0) * 20).toLocaleString()}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/10 rounded-lg p-4 text-center backdrop-blur-sm">
            <p className="text-2xl font-bold" data-testid="text-credits-this-month">
              {/* Calculate from recent transactions */}
              {transactions?.filter((t: any) => {
                const transactionDate = new Date(t.createdAt);
                const thisMonth = new Date();
                return transactionDate.getMonth() === thisMonth.getMonth() &&
                       transactionDate.getFullYear() === thisMonth.getFullYear();
              }).reduce((sum: number, t: any) => sum + t.amount, 0) || 0}
            </p>
            <p className="text-xs opacity-90">This Month</p>
          </div>
          <div className="bg-white/10 rounded-lg p-4 text-center backdrop-blur-sm">
            <p className="text-2xl font-bold" data-testid="text-active-projects">
              {/* This would need to be calculated from user projects */}
              3
            </p>
            <p className="text-xs opacity-90">Active Projects</p>
          </div>
        </div>
      </div>

      {/* Transaction History */}
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-foreground">Transaction History</h2>
          <Button variant="outline" size="sm">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-card border border-border rounded-lg p-4 animate-pulse">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-muted rounded-full"></div>
                    <div className="space-y-2">
                      <div className="h-4 bg-muted rounded w-24"></div>
                      <div className="h-3 bg-muted rounded w-32"></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-4 bg-muted rounded w-16"></div>
                    <div className="h-3 bg-muted rounded w-12"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : transactions && transactions.length > 0 ? (
          <div className="space-y-4">
            {transactions.map((transaction: any) => (
              <Card key={transaction.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        {getTransactionIcon(transaction.type)}
                      </div>
                      <div>
                        <p className="font-medium text-card-foreground">
                          Credits {transaction.type === 'earned' ? 'Earned' : 'Transaction'}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {transaction.description}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-semibold ${getTransactionColor(transaction.type)}`}>
                        +{transaction.amount} Credits
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(transaction.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-muted-foreground">No transactions yet</p>
              <Button 
                variant="link" 
                className="mt-2"
                onClick={() => navigate("/mrv-capture")}
              >
                Start Contributing
              </Button>
            </CardContent>
          </Card>
        )}

        {transactions && transactions.length > 0 && (
          <div className="mt-8 text-center">
            <Button variant="link">Load More Transactions</Button>
          </div>
        )}
      </div>

      <BottomNavigation activeTab="credits" />
    </div>
  );
}
