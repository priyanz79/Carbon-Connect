import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import BottomNavigation from "@/components/bottom-navigation";
import ProjectCard from "@/components/project-card";
import { useLocation } from "wouter";
import { User, Award, Camera, MapPin } from "lucide-react";

export default function Dashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: projects, isLoading: projectsLoading } = useQuery({
    queryKey: ["/api/projects", "userOnly=true"],
    enabled: !!user,
  });

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Show different dashboard based on user role
  if (user && user.role === "verifier") {
    navigate("/verifier");
    return null;
  }

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Dashboard Header */}
      <div className="bg-primary text-primary-foreground px-6 pt-16 pb-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold" data-testid="text-username">
                {user?.firstName && user?.lastName 
                  ? `${user.firstName} ${user.lastName}` 
                  : user?.email}
              </h1>
              <p className="text-sm opacity-90 capitalize">{user?.role} Member</p>
            </div>
          </div>
          <Button
            onClick={handleLogout}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20"
            data-testid="button-logout"
          >
            Logout
          </Button>
        </div>

        {/* Credits Summary */}
        <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm opacity-90">Total Credits Earned</p>
              <p className="text-2xl font-bold" data-testid="text-credits">
                {user?.totalCredits || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <Award className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="p-6">
        <h2 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Button
            variant="outline"
            className="p-4 h-auto flex flex-col items-start space-y-3"
            onClick={() => navigate("/mrv-capture")}
            data-testid="button-capture-evidence"
          >
            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
              <Camera className="w-5 h-5 text-primary" />
            </div>
            <div className="text-left">
              <h3 className="font-medium text-foreground">Capture Evidence</h3>
              <p className="text-xs text-muted-foreground">Record MRV data</p>
            </div>
          </Button>
          
          <Button
            variant="outline"
            className="p-4 h-auto flex flex-col items-start space-y-3"
            onClick={() => navigate("/projects")}
            data-testid="button-view-projects"
          >
            <div className="w-10 h-10 bg-secondary/10 rounded-lg flex items-center justify-center">
              <MapPin className="w-5 h-5 text-secondary" />
            </div>
            <div className="text-left">
              <h3 className="font-medium text-foreground">View Projects</h3>
              <p className="text-xs text-muted-foreground">Browse active projects</p>
            </div>
          </Button>
        </div>
      </div>

      {/* Recent Projects */}
      <div className="px-6 pb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">My Projects</h2>
          <Button 
            variant="link" 
            className="text-primary text-sm font-medium p-0"
            onClick={() => navigate("/projects")}
            data-testid="button-view-all-projects"
          >
            View All
          </Button>
        </div>

        {projectsLoading ? (
          <div className="space-y-3">
            <div className="bg-card border border-border rounded-lg p-4 animate-pulse">
              <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-muted rounded w-full"></div>
            </div>
          </div>
        ) : projects && Array.isArray(projects) && projects.length > 0 ? (
          <div className="space-y-3">
            {projects.slice(0, 2).map((project: any) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-muted-foreground">No projects joined yet</p>
              <Button 
                variant="link" 
                className="mt-2"
                onClick={() => navigate("/projects")}
                data-testid="button-browse-projects"
              >
                Browse Projects
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      <BottomNavigation activeTab="dashboard" />
    </div>
  );
}
