import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import RoleSelection from "@/components/role-selection";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Leaf, Users, Heart, CheckCircle, Settings } from "lucide-react";

export default function Landing() {
  const [selectedRole, setSelectedRole] = useState<string>("community");
  const [isUpdatingRole, setIsUpdatingRole] = useState(false);
  const { toast } = useToast();

  const handleLogin = async () => {
    // Store selected role in localStorage to use after login
    localStorage.setItem("selectedRole", selectedRole);
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section with Video */}
      <div className="relative h-64 bg-gradient-to-br from-primary to-secondary flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-black/30"></div>
        <video 
          className="absolute inset-0 w-full h-full object-cover"
          autoPlay
          loop
          playsInline
          controls
          data-testid="hero-video"
        >
          <source src="/attached_assets/Blue Carbon, Explained _ WWT_1757342104236.mp4" type="video/mp4" />
          {/* Fallback image if video fails to load */}
          <img 
            src="https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
            alt="Blue carbon explained" 
            className="w-full h-full object-cover" 
          />
        </video>
        <div className="relative z-10 text-center text-white px-6">
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
            <Leaf className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold mb-2 drop-shadow-lg">CarbonConnect</h1>
          <p className="text-lg opacity-90 drop-shadow-md">Environmental Monitoring & Verification</p>
        </div>
      </div>

      {/* Role Selection */}
      <div className="p-6 space-y-6">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-semibold text-foreground mb-2">Welcome!</h2>
          <p className="text-muted-foreground">Choose your role to get started</p>
        </div>

        <RoleSelection selectedRole={selectedRole} onRoleChange={setSelectedRole} />

        <div className="pt-6">
          <Button 
            onClick={handleLogin}
            className="w-full bg-primary text-primary-foreground py-4 px-6 rounded-lg font-semibold hover:bg-primary/90 transition-colors"
            data-testid="button-login"
          >
            Continue to Login
          </Button>
        </div>

        <div className="pt-8 text-center">
          <p className="text-xs text-muted-foreground px-4">
            By continuing, you agree to our Terms of Service and Privacy Policy
          </p>
        </div>
      </div>
    </div>
  );
}
