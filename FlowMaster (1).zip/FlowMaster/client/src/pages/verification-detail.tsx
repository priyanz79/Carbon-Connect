import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import MapView from "@/components/map-view";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { ArrowLeft, Flag, User, CheckCircle, Check, X, Maximize } from "lucide-react";

export default function VerificationDetail() {
  const [, params] = useRoute("/verifier/:id");
  const [, navigate] = useLocation();
  const [verificationNotes, setVerificationNotes] = useState("");
  const [creditsAwarded, setCreditsAwarded] = useState(0);
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: submission, isLoading } = useQuery({
    queryKey: ["/api/mrv-submissions", params?.id],
    enabled: !!params?.id,
  });

  const verifyMutation = useMutation({
    mutationFn: async ({ status, notes, credits }: { status: string; notes: string; credits: number }) => {
      await apiRequest("PUT", `/api/mrv-submissions/${params?.id}/verify`, {
        status,
        notes,
        creditsAwarded: credits,
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Submission verification updated",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/verifier/pending-submissions"] });
      navigate("/verifier");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update verification",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !submission) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const handleApprove = () => {
    verifyMutation.mutate({
      status: "approved",
      notes: verificationNotes,
      credits: creditsAwarded,
    });
  };

  const handleReject = () => {
    verifyMutation.mutate({
      status: "rejected",
      notes: verificationNotes,
      credits: 0,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Verification Header */}
      <div className="bg-card border-b border-border px-6 pt-16 pb-4">
        <div className="flex items-center justify-between mb-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/verifier")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-semibold text-foreground">Verify Submission</h1>
          <Button variant="ghost" size="sm">
            <Flag className="w-5 h-5 text-muted-foreground" />
          </Button>
        </div>

        {/* Submission Info */}
        <Card className="bg-muted">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3 mb-2">
              <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground" data-testid="text-submitter-name">
                  {submission.userName}
                </p>
                <p className="text-xs text-muted-foreground">
                  Community Member • Submitted {new Date(submission.createdAt).toLocaleString()}
                </p>
              </div>
            </div>
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>Project: {submission.projectName}</span>
              <span className="flex items-center space-x-1">
                <CheckCircle className="w-3 h-3 text-primary" />
                <span>First-time contributor</span>
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Submission Details */}
      <div className="p-6 space-y-6">
        {/* Project & Event Info */}
        <div>
          <h3 className="font-semibold text-foreground mb-3">Submission Details</h3>
          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Project:</span>
                <span className="text-sm font-medium text-card-foreground">
                  {submission.projectName}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Event Type:</span>
                <span className="text-sm font-medium text-card-foreground capitalize">
                  {submission.eventType}
                </span>
              </div>
              {submission.species && (
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Species:</span>
                  <span className="text-sm font-medium text-card-foreground">
                    {submission.species}
                  </span>
                </div>
              )}
              {submission.saplingsPlanted && (
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Saplings Planted:</span>
                  <span className="text-sm font-medium text-card-foreground">
                    {submission.saplingsPlanted}
                  </span>
                </div>
              )}
              {submission.survivalCount && (
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Survival Count:</span>
                  <span className="text-sm font-medium text-card-foreground">
                    {submission.survivalCount}
                  </span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">GPS Location:</span>
                <span className="text-sm font-medium text-card-foreground">
                  {submission.gpsLatitude && submission.gpsLongitude
                    ? `${parseFloat(submission.gpsLatitude).toFixed(4)}°N, ${parseFloat(submission.gpsLongitude).toFixed(4)}°E`
                    : "Not available"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Timestamp:</span>
                <span className="text-sm font-medium text-card-foreground">
                  {new Date(submission.createdAt).toLocaleString()}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Notes */}
        {submission.notes && (
          <div>
            <h3 className="font-semibold text-foreground mb-3">Field Notes</h3>
            <Card className="bg-muted">
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {submission.notes}
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Photo Evidence */}
        {submission.photos && Array.isArray(submission.photos) && submission.photos.length > 0 && (
          <div>
            <h3 className="font-semibold text-foreground mb-3">Photo Evidence</h3>
            <div className="grid grid-cols-2 gap-3">
              {submission.photos.map((photo: string, index: number) => (
                <div key={index} className="relative">
                  <img 
                    src={photo} 
                    alt={`Evidence ${index + 1}`}
                    className="w-full h-32 object-cover rounded-lg" 
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute top-2 right-2 w-8 h-8 bg-black/50 rounded-full p-0"
                  >
                    <Maximize className="w-4 h-4 text-white" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Map Location */}
        {submission.gpsLatitude && submission.gpsLongitude && (
          <div>
            <h3 className="font-semibold text-foreground mb-3">Location Verification</h3>
            <MapView 
              center={[parseFloat(submission.gpsLatitude), parseFloat(submission.gpsLongitude)]}
              className="h-48 rounded-lg"
            />
          </div>
        )}

        {/* Verification Actions */}
        <div className="space-y-4 pt-4">
          <div>
            <Label className="text-sm font-medium text-foreground mb-2">
              Credits to Award
            </Label>
            <Input 
              type="number"
              value={creditsAwarded}
              onChange={(e) => setCreditsAwarded(Number(e.target.value))}
              placeholder="Enter credits amount"
              data-testid="input-credits-awarded"
            />
          </div>

          <div>
            <Label className="text-sm font-medium text-foreground mb-2">
              Verification Notes (Optional)
            </Label>
            <Textarea 
              rows={3}
              value={verificationNotes}
              onChange={(e) => setVerificationNotes(e.target.value)}
              placeholder="Add verification notes..."
              data-testid="textarea-verification-notes"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={handleApprove}
              disabled={verifyMutation.isPending}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              data-testid="button-approve"
            >
              <Check className="w-5 h-5 mr-2" />
              {verifyMutation.isPending ? "Approving..." : "Approve"}
            </Button>
            <Button
              onClick={handleReject}
              disabled={verifyMutation.isPending}
              variant="destructive"
              data-testid="button-reject"
            >
              <X className="w-5 h-5 mr-2" />
              {verifyMutation.isPending ? "Rejecting..." : "Reject"}
            </Button>
          </div>
          
          <Button variant="outline" className="w-full">
            Request More Information
          </Button>
        </div>
      </div>
    </div>
  );
}
