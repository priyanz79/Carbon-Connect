import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import PhotoUpload from "@/components/photo-upload";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { z } from "zod";
import { ArrowLeft, MapPin, Clock, HelpCircle } from "lucide-react";

const mrvFormSchema = z.object({
  projectId: z.string().min(1, "Please select a project"),
  eventType: z.enum(["baseline", "planting", "monitoring", "maintenance"]),
  species: z.string().optional(),
  saplingsPlanted: z.number().min(0).optional(),
  survivalCount: z.number().min(0).optional(),
  notes: z.string().optional(),
  gpsLatitude: z.number(),
  gpsLongitude: z.number(),
});

type MrvFormData = z.infer<typeof mrvFormSchema>;

export default function MrvCapture() {
  const [, navigate] = useLocation();
  const [photos, setPhotos] = useState<File[]>([]);
  const [location, setLocation] = useState<{latitude: number, longitude: number} | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<MrvFormData>({
    resolver: zodResolver(mrvFormSchema),
    defaultValues: {
      eventType: "planting",
      saplingsPlanted: 0,
      survivalCount: 0,
    },
  });

  const { data: projects } = useQuery({
    queryKey: ["/api/projects", "userOnly=true"],
    enabled: !!user,
  });

  // Get current location
  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Geolocation Not Supported",
        description: "Your browser doesn't support location services",
        variant: "destructive",
      });
      return;
    }
    
    navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation({ latitude, longitude });
          form.setValue("gpsLatitude", latitude);
          form.setValue("gpsLongitude", longitude);
          toast({
            title: "Location Updated",
            description: "GPS coordinates have been captured",
          });
        },
        (error) => {
          console.error("Geolocation error:", error);
          let description = "Unable to get your location";
          
          switch (error.code) {
            case error.PERMISSION_DENIED:
              description = "Location access denied. Please enable location permissions.";
              break;
            case error.POSITION_UNAVAILABLE:
              description = "Location information unavailable.";
              break;
            case error.TIMEOUT:
              description = "Location request timed out.";
              break;
          }
          
          toast({
            title: "Location Error",
            description,
            variant: "destructive",
          });
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 60000
        }
      );
  };

  const submitMutation = useMutation({
    mutationFn: async (data: MrvFormData) => {
      const formData = new FormData();
      
      // Append form data
      Object.entries(data).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          formData.append(key, value.toString());
        }
      });

      // Append photos
      photos.forEach((photo) => {
        formData.append("photos", photo);
      });

      await apiRequest("POST", "/api/mrv-submissions", formData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "MRV submission saved successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/mrv-submissions"] });
      navigate("/");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save MRV submission",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: MrvFormData) => {
    if (!location) {
      toast({
        title: "Location Required",
        description: "Please update your GPS location",
        variant: "destructive",
      });
      return;
    }
    submitMutation.mutate(data);
  };

  // Get current location on mount
  React.useEffect(() => {
    getCurrentLocation();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Capture Header */}
      <div className="bg-card border-b border-border px-6 pt-16 pb-4">
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-semibold text-foreground">Capture Evidence</h1>
          <Button variant="ghost" size="sm">
            <HelpCircle className="w-5 h-5 text-muted-foreground" />
          </Button>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="p-6 space-y-6">
          {/* Project Selection */}
          <FormField
            control={form.control}
            name="projectId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Select Project</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-project">
                      <SelectValue placeholder="Choose a project" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {projects && Array.isArray(projects) && projects.length > 0 ? projects.map((project: any) => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.name}
                      </SelectItem>
                    )) : (
                      <SelectItem value="no-projects" disabled>No projects available</SelectItem>
                    )}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Event Type */}
          <FormField
            control={form.control}
            name="eventType"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Event Type</FormLabel>
                <div className="grid grid-cols-2 gap-3">
                  {["planting", "monitoring", "baseline", "maintenance"].map((type) => (
                    <Button
                      key={type}
                      type="button"
                      variant={field.value === type ? "default" : "outline"}
                      className="capitalize"
                      onClick={() => field.onChange(type)}
                      data-testid={`button-event-${type}`}
                    >
                      {type}
                    </Button>
                  ))}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Location Info */}
          <div>
            <h3 className="font-medium text-foreground mb-4">Location & Time</h3>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-3 mb-3">
                  <MapPin className="w-5 h-5 text-primary" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-card-foreground">GPS Location</p>
                    <p className="text-xs text-muted-foreground" data-testid="text-gps-location">
                      {location 
                        ? `${location.latitude.toFixed(4)}°N, ${location.longitude.toFixed(4)}°E`
                        : "Location not available"}
                    </p>
                  </div>
                  <Button 
                    type="button" 
                    variant="link" 
                    size="sm"
                    onClick={getCurrentLocation}
                    data-testid="button-update-location"
                  >
                    Update
                  </Button>
                </div>
                <div className="flex items-center space-x-3">
                  <Clock className="w-5 h-5 text-secondary" />
                  <div>
                    <p className="text-sm font-medium text-card-foreground">Timestamp</p>
                    <p className="text-xs text-muted-foreground" data-testid="text-timestamp">
                      {new Date().toLocaleString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Evidence Form */}
          <FormField
            control={form.control}
            name="species"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Species Planted</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="e.g., Teak, Neem, Banyan" 
                    {...field}
                    data-testid="input-species"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="saplingsPlanted"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Number of Saplings</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      placeholder="50" 
                      {...field}
                      onChange={(e) => field.onChange(Number(e.target.value))}
                      data-testid="input-saplings-planted"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="survivalCount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Survival Count</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      placeholder="47" 
                      {...field}
                      onChange={(e) => field.onChange(Number(e.target.value))}
                      data-testid="input-survival-count"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Notes</FormLabel>
                <FormControl>
                  <Textarea 
                    rows={3} 
                    placeholder="Additional observations, soil conditions, weather..."
                    {...field}
                    data-testid="textarea-notes"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Photo Upload */}
          <div>
            <h3 className="font-medium text-foreground mb-4">Attach Photos/Videos</h3>
            <PhotoUpload photos={photos} onPhotosChange={setPhotos} />
          </div>

          <div className="space-y-3 pt-4">
            <Button 
              type="submit"
              className="w-full"
              disabled={submitMutation.isPending}
              data-testid="button-submit"
            >
              {submitMutation.isPending ? "Saving..." : "Save & Submit"}
            </Button>
            <Button 
              type="button"
              variant="outline" 
              className="w-full"
              onClick={() => navigate("/")}
              data-testid="button-save-draft"
            >
              Save as Draft
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
