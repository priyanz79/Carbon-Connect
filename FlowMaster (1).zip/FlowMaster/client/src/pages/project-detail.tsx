import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import MapView from "@/components/map-view";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { ArrowLeft, Share, Camera, Eye, Users, Award } from "lucide-react";

export default function ProjectDetail() {
  const [, params] = useRoute("/projects/:id");
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: project, isLoading } = useQuery({
    queryKey: ["/api/projects", params?.id],
    enabled: !!params?.id,
  });

  const { data: submissions, isLoading: submissionsLoading } = useQuery({
    queryKey: ["/api/mrv-submissions", `projectId=${params?.id}`],
    enabled: !!params?.id,
  });

  const joinProjectMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/projects/${params?.id}/join`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Successfully joined project",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to join project",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !project) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-primary text-primary-foreground";
      case "monitoring":
        return "bg-secondary text-black";
      case "completed":
        return "bg-muted text-muted-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Project Header */}
      <div className="relative h-64 bg-gradient-to-b from-transparent to-black/50">
        <img 
          src={project.imageUrl || "https://images.unsplash.com/photo-1448375240586-882707db888b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=300"} 
          alt={project.name}
          className="absolute inset-0 w-full h-full object-cover" 
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/50"></div>
        
        <div className="absolute top-16 left-6 right-6 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/projects")}
            className="w-10 h-10 bg-black/30 backdrop-blur-sm rounded-full"
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="w-10 h-10 bg-black/30 backdrop-blur-sm rounded-full"
          >
            <Share className="w-5 h-5 text-white" />
          </Button>
        </div>

        <div className="absolute bottom-6 left-6 right-6">
          <span className={`text-xs px-3 py-1 rounded-full mb-3 inline-block capitalize ${getStatusBadgeColor(project.status)}`}>
            {project.status} Project
          </span>
          <h1 className="text-2xl font-bold text-white mb-2" data-testid="text-project-name">
            {project.name}
          </h1>
          <p className="text-white/90 text-sm" data-testid="text-project-location">
            📍 {project.location} • {project.participantCount} participants
          </p>
        </div>
      </div>

      {/* Project Stats */}
      <div className="p-6 bg-card">
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="text-center">
            <p className="text-2xl font-bold text-primary" data-testid="text-trees-planted">
              {/* Calculate from submissions */}
              {submissions?.reduce((sum: number, sub: any) => sum + (sub.saplingsPlanted || 0), 0) || 0}
            </p>
            <p className="text-xs text-muted-foreground">Trees Planted</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-secondary" data-testid="text-credits-earned">
              {project.totalCredits || 0}
            </p>
            <p className="text-xs text-muted-foreground">Credits Earned</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground" data-testid="text-survival-rate">
              {submissions?.length > 0 
                ? Math.round((submissions.reduce((sum: number, sub: any) => sum + (sub.survivalCount || sub.saplingsPlanted || 0), 0) / 
                   submissions.reduce((sum: number, sub: any) => sum + (sub.saplingsPlanted || 0), 0)) * 100) || 0
                : 0}%
            </p>
            <p className="text-xs text-muted-foreground">Survival Rate</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <h3 className="font-semibold text-foreground mb-2">Project Description</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {project.description}
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-3">Project Area</h3>
            <MapView 
              polygon={project.polygonData} 
              className="h-48 rounded-lg"
            />
          </div>
        </div>
      </div>

      {/* MRV Submissions */}
      <div className="px-6 pb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Recent MRV Submissions</h3>
          <Button variant="link" className="text-primary text-sm font-medium p-0">
            View All
          </Button>
        </div>

        {submissionsLoading ? (
          <div className="space-y-3">
            <div className="bg-card border border-border rounded-lg p-4 animate-pulse">
              <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-muted rounded w-full"></div>
            </div>
          </div>
        ) : submissions && submissions.length > 0 ? (
          <div className="space-y-3">
            {submissions.slice(0, 3).map((submission: any) => (
              <Card key={submission.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        submission.eventType === 'planting' ? 'bg-primary/10' : 'bg-secondary/10'
                      }`}>
                        {submission.eventType === 'planting' ? (
                          <Camera className="w-5 h-5 text-primary" />
                        ) : (
                          <Eye className="w-5 h-5 text-secondary" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-card-foreground capitalize">
                          {submission.eventType} Event
                        </p>
                        <p className="text-xs text-muted-foreground">
                          by {submission.userName}
                        </p>
                      </div>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full capitalize ${
                      submission.status === 'approved' ? 'bg-primary/10 text-primary' :
                      submission.status === 'rejected' ? 'bg-destructive/10 text-destructive' :
                      'bg-muted text-muted-foreground'
                    }`}>
                      {submission.status}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    {submission.notes || `${submission.eventType} activity recorded`}
                  </p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{new Date(submission.createdAt).toLocaleDateString()}</span>
                    <span className="flex items-center space-x-1">
                      <Camera className="w-3 h-3" />
                      <span>{Array.isArray(submission.photos) ? submission.photos.length : 0} photos</span>
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-muted-foreground">No submissions yet</p>
            </CardContent>
          </Card>
        )}

        <div className="mt-6 space-y-3">
          <Button 
            onClick={() => navigate("/mrv-capture")}
            className="w-full"
            data-testid="button-add-evidence"
          >
            Add MRV Evidence
          </Button>
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => joinProjectMutation.mutate()}
            disabled={joinProjectMutation.isPending}
            data-testid="button-join-project"
          >
            {joinProjectMutation.isPending ? "Joining..." : "Join Project"}
          </Button>
        </div>
      </div>
    </div>
  );
}
