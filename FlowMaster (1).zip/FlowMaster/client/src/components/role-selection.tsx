import { Button } from "@/components/ui/button";
import { Users, Heart, CheckCircle, Settings, ChevronRight } from "lucide-react";

interface RoleSelectionProps {
  selectedRole: string;
  onRoleChange: (role: string) => void;
}

const roles = [
  {
    id: "community",
    name: "Community Member",
    description: "Participate in environmental projects",
    icon: Users,
    bgColor: "bg-primary/10",
    iconColor: "text-primary",
  },
  {
    id: "ngo",
    name: "NGO",
    description: "Manage and create environmental projects",
    icon: Heart,
    bgColor: "bg-secondary/10",
    iconColor: "text-secondary",
  },
  {
    id: "verifier",
    name: "Verifier",
    description: "Review and verify submissions",
    icon: CheckCircle,
    bgColor: "bg-accent/10",
    iconColor: "text-primary",
  },
  {
    id: "admin",
    name: "Administrator",
    description: "System administration and oversight",
    icon: Settings,
    bgColor: "bg-muted",
    iconColor: "text-muted-foreground",
  },
];

export default function RoleSelection({ selectedRole, onRoleChange }: RoleSelectionProps) {
  return (
    <div className="space-y-4">
      {roles.map((role) => {
        const Icon = role.icon;
        const isSelected = selectedRole === role.id;
        
        return (
          <Button
            key={role.id}
            onClick={() => onRoleChange(role.id)}
            variant="ghost"
            className={`w-full p-6 h-auto text-left hover:shadow-md transition-shadow ${
              isSelected ? "ring-2 ring-primary" : ""
            }`}
            data-testid={`button-role-${role.id}`}
          >
            <div className="flex items-center space-x-4">
              <div className={`w-12 h-12 ${role.bgColor} rounded-lg flex items-center justify-center`}>
                <Icon className={`w-6 h-6 ${role.iconColor}`} />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-card-foreground">{role.name}</h3>
                <p className="text-sm text-muted-foreground">{role.description}</p>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </Button>
        );
      })}
    </div>
  );
}
