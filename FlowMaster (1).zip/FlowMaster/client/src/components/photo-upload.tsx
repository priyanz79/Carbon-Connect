import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Camera, Image, X } from "lucide-react";

interface PhotoUploadProps {
  photos: File[];
  onPhotosChange: (photos: File[]) => void;
}

export default function PhotoUpload({ photos, onPhotosChange }: PhotoUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const newPhotos = Array.from(files);
      onPhotosChange([...photos, ...newPhotos]);
    }
  };

  const removePhoto = (index: number) => {
    const updatedPhotos = photos.filter((_, i) => i !== index);
    onPhotosChange(updatedPhotos);
  };

  const openCamera = () => {
    cameraInputRef.current?.click();
  };

  const openGallery = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="space-y-4">
      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={handleFileSelect}
      />
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleFileSelect}
      />

      {/* Camera Capture Button */}
      <Button
        type="button"
        variant="outline"
        onClick={openCamera}
        className="w-full p-6 h-auto border-2 border-dashed border-border hover:bg-accent/80 transition-colors"
        data-testid="button-take-photo"
      >
        <div className="flex flex-col items-center space-y-3">
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
            <Camera className="w-6 h-6 text-primary" />
          </div>
          <div>
            <p className="font-medium text-foreground">Take Photo</p>
            <p className="text-sm text-muted-foreground">Use device camera</p>
          </div>
        </div>
      </Button>

      {/* Gallery Upload */}
      <Button
        type="button"
        variant="outline"
        onClick={openGallery}
        className="w-full p-6 h-auto border-2 border-dashed border-border hover:bg-accent/80 transition-colors"
        data-testid="button-upload-from-gallery"
      >
        <div className="flex flex-col items-center space-y-3">
          <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
            <Image className="w-6 h-6 text-secondary" />
          </div>
          <div>
            <p className="font-medium text-foreground">Upload from Gallery</p>
            <p className="text-sm text-muted-foreground">Select existing photos</p>
          </div>
        </div>
      </Button>

      {/* Photo Previews */}
      {photos.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          {photos.map((photo, index) => (
            <div key={index} className="relative">
              <img 
                src={URL.createObjectURL(photo)} 
                alt={`Preview ${index + 1}`}
                className="w-full h-24 object-cover rounded-lg" 
              />
              <Button
                type="button"
                variant="destructive"
                size="sm"
                onClick={() => removePhoto(index)}
                className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0"
                data-testid={`button-remove-photo-${index}`}
              >
                <X className="w-3 h-3" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
