import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Users, ChevronRight } from "lucide-react";

interface Project {
  id: string;
  name: string;
  description: string;
  location: string;
  status: string;
  participantCount: number;
  totalCredits: number;
  imageUrl?: string;
  createdAt: string;
}

interface ProjectCardProps {
  project: Project;
  onClick?: () => void;
}

export default function ProjectCard({ project, onClick }: ProjectCardProps) {
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "active":
        return "default";
      case "monitoring":
        return "secondary";
      case "completed":
        return "outline";
      default:
        return "outline";
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-primary text-primary-foreground";
      case "monitoring":
        return "bg-secondary text-black";
      case "completed":
        return "bg-muted text-muted-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <Card 
      className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
      onClick={onClick}
      data-testid={`project-card-${project.id}`}
    >
      <div className="relative h-32">
        <img 
          src={project.imageUrl || "https://images.unsplash.com/photo-1448375240586-882707db888b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=300"} 
          alt={project.name}
          className="w-full h-full object-cover" 
        />
        <div className="absolute top-3 right-3">
          <Badge 
            className={`text-xs capitalize ${getStatusBadgeColor(project.status)}`}
          >
            {project.status}
          </Badge>
        </div>
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-semibold text-card-foreground mb-2" data-testid="text-project-name">
          {project.name}
        </h3>
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
          {project.description}
        </p>
        
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
          <span className="flex items-center space-x-1">
            <MapPin className="w-3 h-3" />
            <span data-testid="text-project-location">{project.location}</span>
          </span>
          <span className="flex items-center space-x-1">
            <Users className="w-3 h-3" />
            <span data-testid="text-participant-count">{project.participantCount} participants</span>
          </span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="text-sm">
            <span className="text-primary font-semibold" data-testid="text-total-credits">
              {project.totalCredits}
            </span>
            <span className="text-muted-foreground"> credits earned</span>
          </div>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </div>
      </CardContent>
    </Card>
  );
}
