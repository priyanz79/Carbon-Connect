import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Home, Map, Plus, Award, User } from "lucide-react";

interface BottomNavigationProps {
  activeTab: string;
}

const navItems = [
  { id: "dashboard", label: "Dashboard", icon: Home, path: "/" },
  { id: "projects", label: "Projects", icon: Map, path: "/projects" },
  { id: "capture", label: "Capture", icon: Plus, path: "/mrv-capture", isSpecial: true },
  { id: "credits", label: "Credits", icon: Award, path: "/credits" },
  { id: "profile", label: "Profile", icon: User, path: "/profile" },
];

export default function BottomNavigation({ activeTab }: BottomNavigationProps) {
  const [, navigate] = useLocation();

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
      <div className="flex items-center justify-around py-3">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <Button
              key={item.id}
              variant="ghost"
              className="flex flex-col items-center space-y-1 py-2 px-4 h-auto"
              onClick={() => navigate(item.path)}
              data-testid={`nav-${item.id}`}
            >
              {item.isSpecial ? (
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <Icon className="w-4 h-4 text-white" />
                </div>
              ) : (
                <Icon className={`w-5 h-5 ${isActive ? 'text-primary' : 'text-muted-foreground'}`} />
              )}
              <span className={`text-xs ${
                isActive ? 'text-primary font-medium' : 
                item.isSpecial ? 'text-primary font-medium' : 'text-muted-foreground'
              }`}>
                {item.label}
              </span>
            </Button>
          );
        })}
      </div>
    </div>
  );
}
