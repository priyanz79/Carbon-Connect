# CarbonConnect - Environmental Monitoring & Verification Platform

## Overview

CarbonConnect is a full-stack web application designed for environmental monitoring, reporting, and verification (MRV) of conservation projects. The platform enables different user roles (community members, NGOs, verifiers, and administrators) to collaborate on environmental projects, capture field data with GPS coordinates and photo evidence, and manage a verification workflow for earning carbon credits.

The application serves as a digital platform for tracking environmental activities like tree planting, monitoring, and maintenance, with built-in verification mechanisms to ensure data integrity and support carbon credit generation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom design tokens and CSS variables
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Forms**: React Hook Form with Zod validation
- **Mobile-First**: Responsive design optimized for mobile devices with bottom navigation

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: OpenID Connect (OIDC) with Replit authentication integration
- **Session Management**: Express sessions with PostgreSQL session store
- **File Uploads**: Multer middleware for handling image uploads
- **API Design**: RESTful endpoints with role-based access control

### Database Design
- **Primary Database**: PostgreSQL with Neon serverless driver
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Key Entities**:
  - Users with role-based permissions (community, NGO, verifier, admin)
  - Projects with geographic boundaries and participant management
  - MRV submissions with GPS coordinates, photos, and verification workflow
  - Credit transactions for tracking earned environmental credits
- **Enums**: Strongly typed enums for user roles, event types, and submission statuses

### Authentication & Authorization
- **Authentication Provider**: Replit OIDC integration
- **Session Storage**: PostgreSQL-backed sessions with configurable TTL
- **Role-Based Access**: Four distinct user roles with different capabilities
- **Security**: HTTP-only cookies, CSRF protection, and secure session management

### File Management
- **Upload Handling**: Local file storage with Multer
- **File Validation**: Type and size restrictions for image uploads
- **Storage Strategy**: Files stored in uploads directory with organized naming

### Real-Time Features
- **GPS Integration**: Automatic location capture for field submissions
- **Photo Capture**: Camera and gallery integration for evidence collection
- **Offline Capability**: Local data queuing for sync when online (architectural provision)

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Database Driver**: @neondatabase/serverless for WebSocket-based connections

### Authentication
- **Replit OIDC**: Integrated authentication service for user management
- **OpenID Client**: Standard OIDC implementation for secure authentication flow

### UI Component Libraries
- **Radix UI**: Headless UI primitives for accessibility and behavior
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Type-safe variant-based component styling

### Development Tools
- **Vite**: Fast build tool with HMR and development server
- **ESBuild**: Fast bundling for production builds
- **Replit Integration**: Development environment plugins and error handling

### Validation & Forms
- **Zod**: Runtime type validation and schema definition
- **React Hook Form**: Performant forms with validation integration
- **Hookform Resolvers**: Bridge between React Hook Form and Zod

### Utilities
- **Date-fns**: Date manipulation and formatting
- **Clsx & Tailwind Merge**: Conditional and merged CSS class handling
- **Memoizee**: Function memoization for performance optimization

### Geographic Services
- **Map Integration**: Placeholder for Leaflet or similar mapping library
- **GPS Services**: Browser geolocation API for coordinate capture

### Session Management
- **Connect-PG-Simple**: PostgreSQL session store for Express sessions
- **Express Session**: Server-side session management middleware