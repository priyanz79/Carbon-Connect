import { sql, relations } from "drizzle-orm";
import {
  index,
  jsonb,
  pgTable,
  text,
  timestamp,
  varchar,
  integer,
  decimal,
  boolean,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User roles enum
export const userRoleEnum = pgEnum("user_role", [
  "community",
  "ngo",
  "verifier",
  "admin",
]);

// Event types enum
export const eventTypeEnum = pgEnum("event_type", [
  "baseline",
  "planting",
  "monitoring",
  "maintenance",
]);

// Submission status enum
export const submissionStatusEnum = pgEnum("submission_status", [
  "pending",
  "approved",
  "rejected",
]);

// Project status enum
export const projectStatusEnum = pgEnum("project_status", [
  "active",
  "monitoring",
  "completed",
  "planning",
]);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").notNull().default("community"),
  totalCredits: integer("total_credits").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Projects table
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  polygonData: jsonb("polygon_data"), // GeoJSON polygon
  createdBy: varchar("created_by").notNull().references(() => users.id),
  status: projectStatusEnum("status").default("active"),
  participantCount: integer("participant_count").default(0),
  totalCredits: integer("total_credits").default(0),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Project participants table
export const projectParticipants = pgTable("project_participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  creditsEarned: integer("credits_earned").default(0),
  joinedAt: timestamp("joined_at").defaultNow(),
});

// MRV submissions table
export const mrvSubmissions = pgTable("mrv_submissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  eventType: eventTypeEnum("event_type").notNull(),
  species: text("species"),
  saplingsPlanted: integer("saplings_planted"),
  survivalCount: integer("survival_count"),
  notes: text("notes"),
  gpsLatitude: decimal("gps_latitude", { precision: 10, scale: 8 }),
  gpsLongitude: decimal("gps_longitude", { precision: 11, scale: 8 }),
  photos: jsonb("photos"), // Array of photo URLs
  status: submissionStatusEnum("status").default("pending"),
  verifiedBy: varchar("verified_by").references(() => users.id),
  verificationNotes: text("verification_notes"),
  creditsAwarded: integer("credits_awarded").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  verifiedAt: timestamp("verified_at"),
});

// Credit transactions table
export const creditTransactions = pgTable("credit_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  submissionId: varchar("submission_id").references(() => mrvSubmissions.id),
  amount: integer("amount").notNull(),
  type: text("type").notNull(), // "earned", "transferred", etc.
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  projects: many(projects),
  submissions: many(mrvSubmissions),
  transactions: many(creditTransactions),
  participations: many(projectParticipants),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  creator: one(users, {
    fields: [projects.createdBy],
    references: [users.id],
  }),
  participants: many(projectParticipants),
  submissions: many(mrvSubmissions),
  transactions: many(creditTransactions),
}));

export const projectParticipantsRelations = relations(
  projectParticipants,
  ({ one }) => ({
    project: one(projects, {
      fields: [projectParticipants.projectId],
      references: [projects.id],
    }),
    user: one(users, {
      fields: [projectParticipants.userId],
      references: [users.id],
    }),
  }),
);

export const mrvSubmissionsRelations = relations(mrvSubmissions, ({ one }) => ({
  project: one(projects, {
    fields: [mrvSubmissions.projectId],
    references: [projects.id],
  }),
  user: one(users, {
    fields: [mrvSubmissions.userId],
    references: [users.id],
  }),
  verifier: one(users, {
    fields: [mrvSubmissions.verifiedBy],
    references: [users.id],
  }),
}));

export const creditTransactionsRelations = relations(
  creditTransactions,
  ({ one }) => ({
    user: one(users, {
      fields: [creditTransactions.userId],
      references: [users.id],
    }),
    project: one(projects, {
      fields: [creditTransactions.projectId],
      references: [projects.id],
    }),
    submission: one(mrvSubmissions, {
      fields: [creditTransactions.submissionId],
      references: [mrvSubmissions.id],
    }),
  }),
);

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMrvSubmissionSchema = createInsertSchema(mrvSubmissions).omit({
  id: true,
  createdAt: true,
  verifiedAt: true,
});

export const insertCreditTransactionSchema = createInsertSchema(creditTransactions).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type ProjectParticipant = typeof projectParticipants.$inferSelect;
export type MrvSubmission = typeof mrvSubmissions.$inferSelect;
export type CreditTransaction = typeof creditTransactions.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type InsertMrvSubmission = z.infer<typeof insertMrvSubmissionSchema>;
export type InsertCreditTransaction = z.infer<typeof insertCreditTransactionSchema>;
