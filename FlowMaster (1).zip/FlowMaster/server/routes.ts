import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertProjectSchema, insertMrvSubmissionSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import { promises as fs } from "fs";

// Configure multer for file uploads
const upload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type"));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Update user role
  app.patch("/api/auth/user/role", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { role } = req.body;
      
      // Validate role
      if (!role || !['community', 'ngo', 'verifier', 'admin'].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }

      await storage.updateUserRole(userId, role);
      const updatedUser = await storage.getUser(userId);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Project routes
  app.get("/api/projects", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userProjects = req.query.userOnly === "true";
      
      const projects = userProjects 
        ? await storage.getUserProjects(userId)
        : await storage.getProjects();
      
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", isAuthenticated, async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectData = insertProjectSchema.parse({
        ...req.body,
        createdBy: userId,
      });

      const project = await storage.createProject(projectData);
      res.status(201).json(project);
    } catch (error) {
      console.error("Error creating project:", error);
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  app.post("/api/projects/:id/join", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.joinProject(req.params.id, userId);
      res.json({ message: "Successfully joined project" });
    } catch (error) {
      console.error("Error joining project:", error);
      res.status(500).json({ message: "Failed to join project" });
    }
  });

  // MRV submission routes
  app.get("/api/mrv-submissions", isAuthenticated, async (req: any, res) => {
    try {
      const { projectId, status } = req.query;
      const submissions = await storage.getMrvSubmissions(projectId, status);
      res.json(submissions);
    } catch (error) {
      console.error("Error fetching MRV submissions:", error);
      res.status(500).json({ message: "Failed to fetch MRV submissions" });
    }
  });

  app.get("/api/mrv-submissions/:id", isAuthenticated, async (req, res) => {
    try {
      const submission = await storage.getMrvSubmission(req.params.id);
      if (!submission) {
        return res.status(404).json({ message: "Submission not found" });
      }
      res.json(submission);
    } catch (error) {
      console.error("Error fetching MRV submission:", error);
      res.status(500).json({ message: "Failed to fetch MRV submission" });
    }
  });

  app.post("/api/mrv-submissions", isAuthenticated, upload.array("photos", 5), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const files = req.files as Express.Multer.File[];
      
      // Process uploaded photos
      const photoUrls: string[] = [];
      if (files) {
        for (const file of files) {
          // In a real app, you'd upload to cloud storage
          // For now, just store the filename
          photoUrls.push(`/uploads/${file.filename}`);
        }
      }

      const submissionData = insertMrvSubmissionSchema.parse({
        ...req.body,
        userId,
        photos: photoUrls,
      });

      const submission = await storage.createMrvSubmission(submissionData);
      res.status(201).json(submission);
    } catch (error) {
      console.error("Error creating MRV submission:", error);
      res.status(500).json({ message: "Failed to create MRV submission" });
    }
  });

  app.put("/api/mrv-submissions/:id/verify", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { status, notes, creditsAwarded } = req.body;
      
      await storage.updateMrvSubmissionStatus(
        req.params.id,
        status,
        userId,
        notes,
        creditsAwarded
      );

      // If approved, create credit transaction and update user credits
      if (status === "approved" && creditsAwarded) {
        const submission = await storage.getMrvSubmission(req.params.id);
        if (submission) {
          await storage.createCreditTransaction({
            userId: submission.userId,
            projectId: submission.projectId,
            submissionId: submission.id,
            amount: creditsAwarded,
            type: "earned",
            description: `Credits earned for ${submission.eventType} verification`,
          });

          await storage.updateUserCredits(submission.userId, creditsAwarded);
        }
      }

      res.json({ message: "Submission verification updated" });
    } catch (error) {
      console.error("Error verifying submission:", error);
      res.status(500).json({ message: "Failed to verify submission" });
    }
  });

  // Verifier-specific routes
  app.get("/api/verifier/pending-submissions", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "verifier") {
        return res.status(403).json({ message: "Access denied" });
      }

      const submissions = await storage.getPendingSubmissions();
      res.json(submissions);
    } catch (error) {
      console.error("Error fetching pending submissions:", error);
      res.status(500).json({ message: "Failed to fetch pending submissions" });
    }
  });

  // Credit routes
  app.get("/api/credits/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const transactions = await storage.getCreditTransactions(userId);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching credit transactions:", error);
      res.status(500).json({ message: "Failed to fetch credit transactions" });
    }
  });

  // File serving
  app.use("/uploads", express.static("uploads"));

  const httpServer = createServer(app);
  return httpServer;
}
