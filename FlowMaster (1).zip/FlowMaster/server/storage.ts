import {
  users,
  projects,
  projectParticipants,
  mrvSubmissions,
  creditTransactions,
  type User,
  type UpsertUser,
  type Project,
  type MrvSubmission,
  type CreditTransaction,
  type InsertProject,
  type InsertMrvSubmission,
  type InsertCreditTransaction,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserRole(id: string, role: string): Promise<void>;

  // Project operations
  getProjects(userId?: string): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  joinProject(projectId: string, userId: string): Promise<void>;
  getUserProjects(userId: string): Promise<Project[]>;

  // MRV submission operations
  getMrvSubmissions(projectId?: string, status?: string): Promise<any[]>;
  getMrvSubmission(id: string): Promise<any | undefined>;
  createMrvSubmission(submission: InsertMrvSubmission): Promise<MrvSubmission>;
  updateMrvSubmissionStatus(
    id: string,
    status: string,
    verifiedBy: string,
    notes?: string,
    creditsAwarded?: number
  ): Promise<void>;
  getPendingSubmissions(): Promise<any[]>;

  // Credit operations
  getCreditTransactions(userId: string): Promise<CreditTransaction[]>;
  createCreditTransaction(transaction: InsertCreditTransaction): Promise<CreditTransaction>;
  updateUserCredits(userId: string, credits: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserRole(id: string, role: string): Promise<void> {
    await db
      .update(users)
      .set({ 
        role: role as any,
        updatedAt: new Date() 
      })
      .where(eq(users.id, id));
  }

  // Project operations
  async getProjects(userId?: string): Promise<Project[]> {
    if (userId) {
      const result = await db
        .select({
          id: projects.id,
          name: projects.name,
          description: projects.description,
          location: projects.location,
          polygonData: projects.polygonData,
          createdBy: projects.createdBy,
          status: projects.status,
          participantCount: projects.participantCount,
          totalCredits: projects.totalCredits,
          imageUrl: projects.imageUrl,
          createdAt: projects.createdAt,
          updatedAt: projects.updatedAt,
        })
        .from(projects)
        .leftJoin(projectParticipants, eq(projectParticipants.projectId, projects.id))
        .where(eq(projectParticipants.userId, userId))
        .orderBy(desc(projects.createdAt));
      return result;
    }
    
    return await db
      .select()
      .from(projects)
      .orderBy(desc(projects.createdAt));
  }

  async getProject(id: string): Promise<Project | undefined> {
    const [project] = await db
      .select()
      .from(projects)
      .where(eq(projects.id, id));
    return project;
  }

  async createProject(projectData: InsertProject): Promise<Project> {
    const [project] = await db
      .insert(projects)
      .values(projectData)
      .returning();
    
    // Auto-join the creator to the project
    await this.joinProject(project.id, projectData.createdBy);
    
    return project;
  }

  async joinProject(projectId: string, userId: string): Promise<void> {
    await db
      .insert(projectParticipants)
      .values({
        projectId,
        userId,
      })
      .onConflictDoNothing();

    // Update participant count
    await db
      .update(projects)
      .set({
        participantCount: sql`${projects.participantCount} + 1`,
        updatedAt: new Date(),
      })
      .where(eq(projects.id, projectId));
  }

  async getUserProjects(userId: string): Promise<Project[]> {
    const result = await db
      .select({
        id: projects.id,
        name: projects.name,
        description: projects.description,
        location: projects.location,
        polygonData: projects.polygonData,
        createdBy: projects.createdBy,
        status: projects.status,
        participantCount: projects.participantCount,
        totalCredits: projects.totalCredits,
        imageUrl: projects.imageUrl,
        createdAt: projects.createdAt,
        updatedAt: projects.updatedAt,
      })
      .from(projects)
      .innerJoin(projectParticipants, eq(projectParticipants.projectId, projects.id))
      .where(eq(projectParticipants.userId, userId))
      .orderBy(desc(projects.createdAt));
    
    return result;
  }

  // MRV submission operations
  async getMrvSubmissions(projectId?: string, status?: string): Promise<any[]> {
    let query = db
      .select({
        id: mrvSubmissions.id,
        projectId: mrvSubmissions.projectId,
        userId: mrvSubmissions.userId,
        eventType: mrvSubmissions.eventType,
        species: mrvSubmissions.species,
        saplingsPlanted: mrvSubmissions.saplingsPlanted,
        survivalCount: mrvSubmissions.survivalCount,
        notes: mrvSubmissions.notes,
        gpsLatitude: mrvSubmissions.gpsLatitude,
        gpsLongitude: mrvSubmissions.gpsLongitude,
        photos: mrvSubmissions.photos,
        status: mrvSubmissions.status,
        verifiedBy: mrvSubmissions.verifiedBy,
        verificationNotes: mrvSubmissions.verificationNotes,
        creditsAwarded: mrvSubmissions.creditsAwarded,
        createdAt: mrvSubmissions.createdAt,
        verifiedAt: mrvSubmissions.verifiedAt,
        projectName: projects.name,
        userName: sql<string>`CONCAT(${users.firstName}, ' ', ${users.lastName})`,
      })
      .from(mrvSubmissions)
      .leftJoin(projects, eq(mrvSubmissions.projectId, projects.id))
      .leftJoin(users, eq(mrvSubmissions.userId, users.id));

    if (projectId) {
      query = query.where(eq(mrvSubmissions.projectId, projectId));
    }

    if (status) {
      query = query.where(eq(mrvSubmissions.status, status as any));
    }

    return await query.orderBy(desc(mrvSubmissions.createdAt));
  }

  async getMrvSubmission(id: string): Promise<any | undefined> {
    const [submission] = await db
      .select({
        id: mrvSubmissions.id,
        projectId: mrvSubmissions.projectId,
        userId: mrvSubmissions.userId,
        eventType: mrvSubmissions.eventType,
        species: mrvSubmissions.species,
        saplingsPlanted: mrvSubmissions.saplingsPlanted,
        survivalCount: mrvSubmissions.survivalCount,
        notes: mrvSubmissions.notes,
        gpsLatitude: mrvSubmissions.gpsLatitude,
        gpsLongitude: mrvSubmissions.gpsLongitude,
        photos: mrvSubmissions.photos,
        status: mrvSubmissions.status,
        verifiedBy: mrvSubmissions.verifiedBy,
        verificationNotes: mrvSubmissions.verificationNotes,
        creditsAwarded: mrvSubmissions.creditsAwarded,
        createdAt: mrvSubmissions.createdAt,
        verifiedAt: mrvSubmissions.verifiedAt,
        projectName: projects.name,
        userName: sql<string>`CONCAT(${users.firstName}, ' ', ${users.lastName})`,
      })
      .from(mrvSubmissions)
      .leftJoin(projects, eq(mrvSubmissions.projectId, projects.id))
      .leftJoin(users, eq(mrvSubmissions.userId, users.id))
      .where(eq(mrvSubmissions.id, id));
    
    return submission;
  }

  async createMrvSubmission(submissionData: InsertMrvSubmission): Promise<MrvSubmission> {
    const [submission] = await db
      .insert(mrvSubmissions)
      .values(submissionData)
      .returning();
    return submission;
  }

  async updateMrvSubmissionStatus(
    id: string,
    status: string,
    verifiedBy: string,
    notes?: string,
    creditsAwarded?: number
  ): Promise<void> {
    await db
      .update(mrvSubmissions)
      .set({
        status: status as any,
        verifiedBy,
        verificationNotes: notes,
        creditsAwarded,
        verifiedAt: new Date(),
      })
      .where(eq(mrvSubmissions.id, id));
  }

  async getPendingSubmissions(): Promise<any[]> {
    return this.getMrvSubmissions(undefined, "pending");
  }

  // Credit operations
  async getCreditTransactions(userId: string): Promise<CreditTransaction[]> {
    return await db
      .select()
      .from(creditTransactions)
      .where(eq(creditTransactions.userId, userId))
      .orderBy(desc(creditTransactions.createdAt));
  }

  async createCreditTransaction(
    transactionData: InsertCreditTransaction
  ): Promise<CreditTransaction> {
    const [transaction] = await db
      .insert(creditTransactions)
      .values(transactionData)
      .returning();
    return transaction;
  }

  async updateUserCredits(userId: string, credits: number): Promise<void> {
    await db
      .update(users)
      .set({
        totalCredits: sql`${users.totalCredits} + ${credits}`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }
}

export const storage = new DatabaseStorage();
